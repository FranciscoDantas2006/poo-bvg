#include <iostream>
#include <string>
#include "SistemaAcademico.h"
#include "SinalHandler.h"

// Função para adicionar aluno
Aluno criarAluno() {
    int id;
    std::string nome;
    std::cout << "Digite o ID do aluno: ";
    std::cin >> id;
    std::cin.ignore();
    std::cout << "Digite o nome do aluno: ";
    std::getline(std::cin, nome);

    return Aluno(id, nome);
}

// Função para adicionar professor
Professor criarProfessor() {
    int id;
    std::string nome;
    std::cout << "Digite o ID do professor: ";
    std::cin >> id;
    std::cin.ignore();
    std::cout << "Digite o nome do professor: ";
    std::getline(std::cin, nome);

    return Professor(id, nome);
}

// Função para adicionar disciplina
Disciplina criarDisciplina() {
    std::string codigo, nome;
    int professorId;

    std::cout << "Digite o código da disciplina: ";
    std::cin >> codigo;
    std::cin.ignore();
    std::cout << "Digite o nome da disciplina: ";
    std::getline(std::cin, nome);
    std::cout << "Digite o ID do professor responsável: ";
    std::cin >> professorId;
    std::cin.ignore();

    return Disciplina(codigo, nome, professorId);
}

// Função para confirmar inscrição
bool confirmarInscricao(const std::string& tipo, const std::string& nome) {
    char resposta;
    std::cout << "Deseja realmente cadastrar " << tipo << " '" << nome << "'? (s/n): ";
    std::cin >> resposta;
    std::cin.ignore();
    return (resposta == 's' || resposta == 'S');
}

int main() {
    SistemaAcademico sistema;
    sistema.carregarTudo();
    SinalHandler::inicializar(&sistema);

    try {
        std::cout << "=== Cadastro Interativo ===\n";

        // Aluno
        Aluno aluno = criarAluno();
        if (confirmarInscricao("aluno", aluno.getNome())) {
            sistema.adicionarAluno(aluno);
            std::cout << "Aluno cadastrado com sucesso!\n";
        } else {
            std::cout << "Cadastro de aluno cancelado.\n";
        }

        // Professor
        Professor professor = criarProfessor();
        if (confirmarInscricao("professor", professor.getNome())) {
            sistema.adicionarProfessor(professor);
            std::cout << "Professor cadastrado com sucesso!\n";
        } else {
            std::cout << "Cadastro de professor cancelado.\n";
        }

        // Disciplina
        Disciplina disciplina = criarDisciplina();
        if (confirmarInscricao("disciplina", disciplina.getNome())) {
            sistema.adicionarDisciplina(disciplina);
            std::cout << "Disciplina cadastrada com sucesso!\n";
        } else {
            std::cout << "Cadastro de disciplina cancelado.\n";
        }

    } catch (const std::exception& e) {
        std::cerr << "Erro: " << e.what() << std::endl;
    }

    std::cout << "Sistema em execução. Pressione Ctrl+C para encerrar.\n";
    while (true) {} // Loop infinito

    return 0;
}