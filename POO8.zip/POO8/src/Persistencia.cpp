#include "Persistencia.h"
#include "Excecoes.h"
#include <fstream>
#include <iostream>

std::vector<std::string> Persistencia::carregar(const std::string& arquivo) {
    std::ifstream fin(arquivo);
    if (!fin.is_open()) throw ArquivoNaoEncontradoException(arquivo);

    std::vector<std::string> linhas;
    std::string linha;
    while (std::getline(fin, linha)) {
        linhas.push_back(linha);
    }
    return linhas;
}

void Persistencia::salvar(const std::string& arquivo, const std::vector<std::string>& dados) {
    std::ofstream fout(arquivo);
    if (!fout.is_open()) throw PermissaoNegadaException(arquivo);

    for (const auto& linha : dados) {
        fout << linha << "\n";
    }
}