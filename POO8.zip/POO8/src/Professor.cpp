#include "Professor.h"
#include <sstream>
#include <stdexcept>

Professor::Professor(int id, const std::string& nome) : id(id), nome(nome) {}

int Professor::getId() const { return id; }
const std::string& Professor::getNome() const { return nome; }

std::string Professor::serialize() const {
    return std::to_string(id) + ";" + nome;
}

Professor Professor::deserialize(const std::string& line) {
    std::stringstream ss(line);
    std::string idStr, nomeStr;
    if (!std::getline(ss, idStr, ';')) throw std::runtime_error("Linha inválida de professor");
    if (!std::getline(ss, nomeStr)) throw std::runtime_error("Linha inválida de professor");
    return Professor(std::stoi(idStr), nomeStr);
}