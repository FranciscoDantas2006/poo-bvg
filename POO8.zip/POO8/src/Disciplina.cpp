#include "Disciplina.h"
#include <sstream>
#include <stdexcept>

Disciplina::Disciplina(const std::string& codigo, const std::string& nome, int professorId)
    : codigo(codigo), nome(nome), professorId(professorId) {}

const std::string& Disciplina::getCodigo() const { return codigo; }
const std::string& Disciplina::getNome() const { return nome; }
int Disciplina::getProfessorId() const { return professorId; }

std::string Disciplina::serialize() const {
    return codigo + ";" + nome + ";" + std::to_string(professorId);
}

Disciplina Disciplina::deserialize(const std::string& line) {
    std::stringstream ss(line);
    std::string codigoStr, nomeStr, profIdStr;
    if (!std::getline(ss, codigoStr, ';')) throw std::runtime_error("Linha inválida de disciplina");
    if (!std::getline(ss, nomeStr, ';')) throw std::runtime_error("Linha inválida de disciplina");
    if (!std::getline(ss, profIdStr)) throw std::runtime_error("Linha inválida de disciplina");
    return Disciplina(codigoStr, nomeStr, std::stoi(profIdStr));
}