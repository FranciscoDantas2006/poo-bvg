#include "SinalHandler.h"
#include "SistemaAcademico.h"
#include <iostream>
#include <cstdlib>

SistemaAcademico* SinalHandler::sistema = nullptr;

void SinalHandler::inicializar(SistemaAcademico* sistemaInstance) {
    sistema = sistemaInstance;
    std::signal(SIGINT, tratador);
    std::signal(SIGTERM, tratador);
    std::signal(SIGSEGV, tratador);
}

void SinalHandler::tratador(int sinal) {
    if (sistema) {
        std::cout << "\n[SINAL] Capturado: " << sinal << ". Salvando dados..." << std::endl;
        sistema->salvarTudo();
    }
    switch (sinal) {
        case SIGINT:
            std::cout << "Encerrado por Ctrl+C\n";
            break;
        case SIGTERM:
            std::cout << "Encerrado por requisição do SO\n";
            break;
        case SIGSEGV:
            std::cout << "Falha de segmentação detectada!\n";
            break;
        default:
            std::cout << "Sinal desconhecido: " << sinal << "\n";
    }
    std::exit(1);
}