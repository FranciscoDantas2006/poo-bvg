#include "Aluno.h"
#include <sstream>
#include <stdexcept>

Aluno::Aluno(int id, const std::string& nome) : id(id), nome(nome) {}

int Aluno::getId() const { return id; }
const std::string& Aluno::getNome() const { return nome; }

std::string Aluno::serialize() const {
    return std::to_string(id) + ";" + nome;
}

Aluno Aluno::deserialize(const std::string& line) {
    std::stringstream ss(line);
    std::string idStr, nomeStr;
    if (!std::getline(ss, idStr, ';')) throw std::runtime_error("Linha inválida de aluno");
    if (!std::getline(ss, nomeStr)) throw std::runtime_error("Linha inválida de aluno");
    return Aluno(std::stoi(idStr), nomeStr);
}