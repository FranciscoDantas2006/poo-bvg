#include "SistemaAcademico.h"
#include "Persistencia.h"
#include "Excecoes.h"
#include <iostream>

void SistemaAcademico::carregarTudo() {
    try {
        auto linhasAlunos = Persistencia::carregar(arquivoAlunos);
        for (auto& l : linhasAlunos) alunos.push_back(Aluno::deserialize(l));
    } catch (...) {
        std::cout << "[INFO] Nenhum aluno carregado\n";
    }

    try {
        auto linhasProfessores = Persistencia::carregar(arquivoProfessores);
        for (auto& l : linhasProfessores) professores.push_back(Professor::deserialize(l));
    } catch (...) {
        std::cout << "[INFO] Nenhum professor carregado\n";
    }

    try {
        auto linhasDisciplinas = Persistencia::carregar(arquivoDisciplinas);
        for (auto& l : linhasDisciplinas) disciplinas.push_back(Disciplina::deserialize(l));
    } catch (...) {
        std::cout << "[INFO] Nenhuma disciplina carregada\n";
    }
}

void SistemaAcademico::salvarTudo() {
    Persistencia::salvar(arquivoAlunos, alunosParaLinhas());
    Persistencia::salvar(arquivoProfessores, professoresParaLinhas());
    Persistencia::salvar(arquivoDisciplinas, disciplinasParaLinhas());
}

void SistemaAcademico::adicionarAluno(const Aluno& a) {
    alunos.push_back(a);
    salvarTudo();
}

void SistemaAcademico::adicionarProfessor(const Professor& p) {
    professores.push_back(p);
    salvarTudo();
}

void SistemaAcademico::adicionarDisciplina(const Disciplina& d) {
    disciplinas.push_back(d);
    salvarTudo();
}

std::vector<std::string> SistemaAcademico::alunosParaLinhas() const {
    std::vector<std::string> linhas;
    for (const auto& a : alunos) linhas.push_back(a.serialize());
    return linhas;
}

std::vector<std::string> SistemaAcademico::professoresParaLinhas() const {
    std::vector<std::string> linhas;
    for (const auto& p : professores) linhas.push_back(p.serialize());
    return linhas;
}

std::vector<std::string> SistemaAcademico::disciplinasParaLinhas() const {
    std::vector<std::string> linhas;
    for (const auto& d : disciplinas) linhas.push_back(d.serialize());
    return linhas;
}