#ifndef PROFESSOR_H
#define PROFESSOR_H

#include <string>

class Professor {
public:
    Professor() = default;
    Professor(int id, const std::string& nome);

    int getId() const;
    const std::string& getNome() const;

    std::string serialize() const;
    static Professor deserialize(const std::string& line);

private:
    int id {0};
    std::string nome;
};

#endif // PROFESSOR_H