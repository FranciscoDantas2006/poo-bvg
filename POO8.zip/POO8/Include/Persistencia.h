#ifndef PERSISTENCIA_H
#define PERSISTENCIA_H

#include <string>
#include <vector>

class Persistencia {
public:
    static std::vector<std::string> carregar(const std::string& arquivo);
    static void salvar(const std::string& arquivo, const std::vector<std::string>& dados);
};

#endif // PERSISTENCIA_H