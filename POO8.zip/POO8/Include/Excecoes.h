#ifndef EXCECOES_H
#define EXCECOES_H

#include <stdexcept>
#include <string>

class ArquivoNaoEncontradoException : public std::runtime_error {
public:
    explicit ArquivoNaoEncontradoException(const std::string& msg)
        : std::runtime_error("Arquivo não encontrado: " + msg) {}
};

class PermissaoNegadaException : public std::runtime_error {
public:
    explicit PermissaoNegadaException(const std::string& msg)
        : std::runtime_error("Permissão negada: " + msg) {}
};

class ConversaoInvalidaException : public std::runtime_error {
public:
    explicit ConversaoInvalidaException(const std::string& msg)
        : std::runtime_error("Erro de conversão: " + msg) {}
};

#endif // EXCECOES_H