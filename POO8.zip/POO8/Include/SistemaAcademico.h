#ifndef SISTEMAACADEMICO_H
#define SISTEMAACADEMICO_H

#include <vector>
#include <string>
#include "Aluno.h"
#include "Professor.h"
#include "Disciplina.h"

class SistemaAcademico {
public:
    SistemaAcademico() = default;

    void carregarTudo();
    void salvarTudo();

    void adicionarAluno(const Aluno& a);
    void adicionarProfessor(const Professor& p);
    void adicionarDisciplina(const Disciplina& d);

    const std::vector<Aluno>& getAlunos() const { return alunos; }
    const std::vector<Professor>& getProfessores() const { return professores; }
    const std::vector<Disciplina>& getDisciplinas() const { return disciplinas; }

private:
    std::vector<Aluno> alunos;
    std::vector<Professor> professores;
    std::vector<Disciplina> disciplinas;

    const std::string arquivoAlunos = "alunos.txt";
    const std::string arquivoProfessores = "professores.txt";
    const std::string arquivoDisciplinas = "disciplinas.txt";

    std::vector<std::string> alunosParaLinhas() const;
    std::vector<std::string> professoresParaLinhas() const;
    std::vector<std::string> disciplinasParaLinhas() const;
};

#endif // SISTEMAACADEMICO_H