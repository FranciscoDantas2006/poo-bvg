#ifndef ALUNO_H
#define ALUNO_H

#include <string>

class Aluno {
public:
    Aluno() = default;
    Aluno(int id, const std::string& nome);

    int getId() const;
    const std::string& getNome() const;

    std::string serialize() const; 
    static Aluno deserialize(const std::string& line);

private:
    int id {0};
    std::string nome;
};

#endif // ALUNO_H