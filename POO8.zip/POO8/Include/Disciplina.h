#ifndef DISCIPLINA_H
#define DISCIPLINA_H

#include <string>

class Disciplina {
public:
    Disciplina() = default;
    Disciplina(const std::string& codigo, const std::string& nome, int professorId);

    const std::string& getCodigo() const;
    const std::string& getNome() const;
    int getProfessorId() const;

    std::string serialize() const;
    static Disciplina deserialize(const std::string& line);

private:
    std::string codigo;
    std::string nome;
    int professorId {0};
};

#endif // DISCIPLINA_H