#ifndef SINALHANDLER_H
#define SINALHANDLER_H

#include <csignal>

class SistemaAcademico; // forward declaration

class SinalHandler {
public:
    static void inicializar(SistemaAcademico* sistemaInstance);
private:
    static void tratador(int sinal);
    static SistemaAcademico* sistema;
};

#endif // SINALHANDLER_H