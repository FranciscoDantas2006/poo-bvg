# Projeto Avaliativo 8 — Tratamento de Exceções e Sinais (C++)

**Aluno:** Francisco Vitor

---

## Descrição

Este projeto consiste na implementação de um **sistema acadêmico simples** em C++, com as funcionalidades de:

- Cadastro de **alunos**, **professores** e **disciplinas**.
- **Tratamento de exceções** para evitar falhas na execução durante a adição de registros.
- **Tratamento de sinais**, permitindo que o programa continue executando e que dados possam ser salvos ou processados ao receber sinais do sistema (ex.: Ctrl+C).

O projeto foi desenvolvido com foco em boas práticas de programação, modularidade e interação com o usuário.

---

## Funcionalidades

1. **Cadastro Interativo**
   - O usuário pode digitar os dados de alunos, professores e disciplinas.
   - Antes de confirmar cada cadastro, o sistema pergunta se deseja realmente adicionar o registro. 's' para sim e 'n' para não.

2. **Tratamento de Exceções**
   - Possibilidade de capturar erros ao tentar adicionar registros inválidos ou duplicados.
   - Exceções são tratadas com mensagens amigáveis ao usuário.

3. **Tratamento de Sinais**
   - Permite que o sistema continue em execução após receber sinais.
   - Possibilidade de salvar os dados antes de encerrar, evitando perda de informações.

---

## Estrutura do Projeto

- `main.cpp` — Contém a função principal, cadastro interativo e loop de execução.
- `SistemaAcademico.h/cpp` — Classe responsável por armazenar e gerenciar alunos, professores e disciplinas.
- `Aluno.h/cpp`, `Professor.h/cpp`, `Disciplina.h/cpp` — Classes de cada entidade do sistema.
- `SinalHandler.h/cpp` — Classe responsável por tratar sinais do sistema (ex.: Ctrl+C).

---

## Como Executar

1. Para um resultado mais rápido, acesse o OnlineGDB, suba os arquivos lá, selecione C++ e dê Run. Lá irá aparecer a opção de escrever:
• Nome do Aluno
• ID do Aluno
• Confirmação (s/n)

• Nome do Professor
• ID do Professor
• Confirmação (s/n)

• Nome da Disciplina
• ID do responsável pela matéria